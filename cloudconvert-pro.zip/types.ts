

export enum Theme {
  Light = 'light',
  Dark = 'dark',
}

export interface FileObject {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  previewUrl?: string; // For image previews
  status: 'pending' | 'uploading' | 'processing' | 'completed' | 'error' | 'paused';
  progress: number; // 0-100
  outputFormat?: string;
  convertedSize?: number;
  downloadUrl?: string; // Simulated
  shareLink?: string; // Simulated
  errorMessage?: string;
  estimatedTime?: number; // in seconds
  _intervalId?: number; // Stores the interval ID for cancellable operations
}

export interface ConversionJob extends FileObject {
  targetFormat: string;
  advancedSettings?: Record<string, any>; 
  // _intervalId is now inherited from FileObject
}

export interface FormatOption {
  value: string;
  label: string;
  category: 'document' | 'image' | 'video' | 'audio' | 'archive';
}

export interface AiSuggestion {
  id: string;
  inputFormat: string;
  recommendedFormat: string;
  reason: string;
}

export interface HistoryItem extends FileObject {
  conversionDate: Date;
  targetFormat: string;
}

// Cloud provider integration types (conceptual)
export enum CloudProvider {
    GoogleDrive = "Google Drive",
    Dropbox = "Dropbox",
    OneDrive = "OneDrive"
}