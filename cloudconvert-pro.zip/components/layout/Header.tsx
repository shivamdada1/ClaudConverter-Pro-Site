
import React from 'react';
import { Sun, Moon } from 'lucide-react';
import Logo from '../ui/Logo';
import ToggleSwitch from '../ui/ToggleSwitch';
import { useTheme } from '../../hooks/useTheme';
import { Theme } from '../../types';

const Header: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-lg bg-light-surface/70 dark:bg-dark-bg/70 border-b border-light-border dark:border-dark-border">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Logo className="h-8 md:h-10" />
        <div className="flex items-center space-x-4">
          {/* Future navigation items can go here */}
          <ToggleSwitch
            checked={theme === Theme.Dark}
            onChange={toggleTheme}
            srLabel="Toggle dark mode"
            IconOn={<Moon size={12} />}
            IconOff={<Sun size={12} />}
          />
        </div>
      </div>
    </header>
  );
};

export default Header;
