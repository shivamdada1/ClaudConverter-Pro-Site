
import React from 'react';
import { APP_NAME } from '../../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-light-surface dark:bg-dark-surface border-t border-light-border dark:border-dark-border mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-light-text-secondary dark:text-dark-text-secondary">
        <p>&copy; {new Date().getFullYear()} {APP_NAME}. All rights reserved. (Simulated Service)</p>
        <p className="text-xs mt-2">
          This is a demonstration application. No real file conversions or storage occur.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
