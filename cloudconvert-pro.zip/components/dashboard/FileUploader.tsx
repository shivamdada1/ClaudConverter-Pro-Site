
import React, { useState, useCallback } from 'react';
import { UploadCloud, FilePlus, X, CheckCircle, AlertTriangle } from 'lucide-react';
import Button from '../ui/Button';
import { useFileConversion } from '../../hooks/useFileConversion';
import { MAX_FILE_SIZE_MB, COMMON_FORMATS } from '../../constants';
import { FileObject, CloudProvider } from '../../types';
import FileIcon from '../ui/FileIcon';


const FileUploader: React.FC = () => {
  const [isDragging, setIsDragging] = useState(false);
  const { addFiles, filesToConvert } = useFileConversion();
  const [uploadError, setUploadError] = useState<string | null>(null);

  const handleFiles = useCallback((selectedFiles: FileList | null) => {
    if (!selectedFiles) return;
    setUploadError(null);
    const filesArray = Array.from(selectedFiles);
    const validFiles: File[] = [];
    let currentError = null;

    filesArray.forEach(file => {
      if (file.size > MAX_FILE_SIZE_MB * 1024 * 1024) {
        currentError = `File "${file.name}" exceeds ${MAX_FILE_SIZE_MB}MB limit.`;
        return; // Skip this file
      }
      validFiles.push(file);
    });

    if (currentError) {
      setUploadError(currentError);
    }
    if (validFiles.length > 0) {
      addFiles(validFiles);
    }
  }, [addFiles]);

  const onDragEnter = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const onDragLeave = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const onDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    handleFiles(e.dataTransfer.files);
  };

  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFiles(e.target.files);
    e.target.value = ''; // Reset input to allow uploading the same file again
  };
  
  const handleCloudUpload = (provider: CloudProvider) => {
    // Simulate cloud provider integration
    alert(`Simulating file selection from ${provider}... (This is a demo, no actual integration)`);
    // In a real app, you would initiate OAuth flow or use a file picker SDK
  };

  return (
    <div className="w-full p-6 md:p-8 bg-light-surface dark:bg-dark-surface rounded-xl shadow-xl animate-fadeIn">
      <h2 className="text-2xl font-semibold mb-6 text-light-text-primary dark:text-dark-text-primary">Upload Your Files</h2>
      
      <div
        className={`relative border-2 border-dashed rounded-lg p-8 md:p-12 text-center transition-all duration-300
                    ${isDragging ? 'border-electric-blue bg-blue-50 dark:bg-blue-900/[0.2]' : 'border-light-border dark:border-dark-border hover:border-gray-400 dark:hover:border-gray-500'}`}
        onDragEnter={onDragEnter}
        onDragLeave={onDragLeave}
        onDragOver={onDragOver}
        onDrop={onDrop}
      >
        <UploadCloud className={`mx-auto mb-4 w-12 h-12 ${isDragging ? 'text-electric-blue' : 'text-gray-400 dark:text-gray-500'}`} />
        <p className="mb-2 text-lg font-medium text-light-text-primary dark:text-dark-text-primary">
          Drag & drop files here
        </p>
        <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-4">
          or click to browse (Max {MAX_FILE_SIZE_MB}MB per file)
        </p>
        <input
          type="file"
          id="fileUpload"
          multiple
          className="sr-only"
          onChange={onFileChange}
          accept={COMMON_FORMATS.map(f => `.${f.value}`).join(',')} // Basic client-side filtering
        />
        <Button
            variant="primary"
            size="lg"
            onClick={() => document.getElementById('fileUpload')?.click()}
            leftIcon={<FilePlus size={20}/>}
        >
          Choose Files
        </Button>
        {uploadError && (
          <p className="mt-4 text-sm text-red-500 dark:text-red-400 flex items-center justify-center">
            <AlertTriangle size={16} className="mr-1" /> {uploadError}
          </p>
        )}
      </div>

      <div className="mt-6 text-center">
        <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mb-3">Or upload from cloud storage:</p>
        <div className="flex flex-wrap justify-center gap-3">
            {Object.values(CloudProvider).map(provider => (
                 <Button 
                    key={provider}
                    variant="outline" 
                    size="md"
                    onClick={() => handleCloudUpload(provider)}
                    className="flex-grow sm:flex-grow-0"
                >
                    {/* Minimalist icons could go here if available */}
                    {provider}
                </Button>
            ))}
        </div>
      </div>
    </div>
  );
};

export default FileUploader;
