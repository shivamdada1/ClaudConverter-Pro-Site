
import React, { useState } from 'react';
import FileUploader from './FileUploader';
import ConversionQueue from './ConversionQueue';
import DownloadManager from './DownloadManager'; // This will be our history panel
import Button from '../ui/Button';

enum ActiveTab {
  Upload = 'upload',
  Queue = 'queue',
  History = 'history',
}

const DashboardPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<ActiveTab>(ActiveTab.Upload);

  const renderTabContent = () => {
    switch (activeTab) {
      case ActiveTab.Upload:
        return <FileUploader />;
      case ActiveTab.Queue:
        return <ConversionQueue />;
      case ActiveTab.History:
        return <DownloadManager />; // Using DownloadManager as history view
      default:
        return <FileUploader />;
    }
  };

  return (
    <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-6 flex flex-wrap gap-2 border-b border-light-border dark:border-dark-border pb-3">
        <Button 
          variant={activeTab === ActiveTab.Upload ? 'primary' : 'ghost'}
          onClick={() => setActiveTab(ActiveTab.Upload)}
        >
          Upload Files
        </Button>
        <Button 
          variant={activeTab === ActiveTab.Queue ? 'primary' : 'ghost'}
          onClick={() => setActiveTab(ActiveTab.Queue)}
        >
          Conversion Queue
        </Button>
        <Button 
          variant={activeTab === ActiveTab.History ? 'primary' : 'ghost'}
          onClick={() => setActiveTab(ActiveTab.History)}
        >
          History & Downloads
        </Button>
      </div>
      
      {renderTabContent()}
      
      {/* Placeholder for Advanced Settings Panel if it were global, or integrate into items */}
      {/* <AdvancedSettingsPanel /> */}
    </div>
  );
};

export default DashboardPage;
