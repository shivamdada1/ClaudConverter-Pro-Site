
import React from 'react';
import { useFileConversion } from '../../hooks/useFileConversion';
import ConversionItem from './ConversionItem';
import Button from '../ui/Button';
import ProgressBar from '../ui/ProgressBar';
import { Play, Trash2, ListChecks } from 'lucide-react';
import { AiSuggestion } from '../../types';


const AiSuggestionsDisplay: React.FC<{ fileType: string }> = ({ fileType }) => {
    const { getAiSuggestions } = useFileConversion();
    const suggestions = getAiSuggestions(fileType);

    if (!suggestions.length) return null;

    return (
        <div className="mt-4 p-3 bg-blue-50 dark:bg-blue-900/[0.2] rounded-lg border border-blue-200 dark:border-blue-700">
            <h4 className="text-sm font-semibold text-blue-700 dark:text-blue-300 mb-1">AI Suggestions for {fileType || "selected files"}:</h4>
            <ul className="list-disc list-inside space-y-1">
                {suggestions.slice(0,2).map(suggestion => ( // Show max 2 suggestions
                    <li key={suggestion.id} className="text-xs text-blue-600 dark:text-blue-400">
                        Convert to <strong>{suggestion.recommendedFormat.toUpperCase()}</strong>: {suggestion.reason}
                    </li>
                ))}
            </ul>
        </div>
    );
};


const ConversionQueue: React.FC = () => {
  const { filesToConvert, startAllConversions, clearQueue, overallProgress, isProcessing } = useFileConversion();

  if (filesToConvert.length === 0) {
    return (
      <div className="my-8 text-center text-light-text-secondary dark:text-dark-text-secondary animate-fadeIn">
        <ListChecks size={48} className="mx-auto mb-4 opacity-50" />
        <p className="text-lg">Your conversion queue is empty.</p>
        <p>Upload files to get started!</p>
      </div>
    );
  }
  
  const firstPendingFileType = filesToConvert.find(f => f.status === 'pending')?.type;

  return (
    <div className="mt-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-light-text-primary dark:text-dark-text-primary mb-2 sm:mb-0">
          Conversion Queue ({filesToConvert.length})
        </h3>
        <div className="flex space-x-2">
          <Button 
            variant="primary" 
            onClick={startAllConversions} 
            disabled={isProcessing || !filesToConvert.some(f => f.status === 'pending' && f.targetFormat)}
            leftIcon={<Play size={18}/>}
          >
            Start All
          </Button>
          <Button 
            variant="danger" 
            onClick={clearQueue} 
            disabled={isProcessing}
            leftIcon={<Trash2 size={18}/>}
          >
            Clear Queue
          </Button>
        </div>
      </div>

      {filesToConvert.length > 0 && overallProgress > 0 && overallProgress < 100 && (
        <div className="mb-4 p-3 bg-light-surface dark:bg-dark-surface rounded-lg shadow">
            <p className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary mb-1">Overall Progress:</p>
            <ProgressBar progress={overallProgress} size="md" showPercentage />
        </div>
      )}
      
      {firstPendingFileType && <AiSuggestionsDisplay fileType={firstPendingFileType} />}

      <div className="space-y-3 mt-4 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
        {filesToConvert.map((job) => (
          <ConversionItem key={job.id} item={job} />
        ))}
      </div>

      {/* Conceptual: Real-time file size estimator */}
      {/* <div className="mt-4 text-sm text-gray-600 dark:text-gray-400">
        Estimated total output size: (Conceptual)
      </div> */}
      
      {/* Conceptual: Reorder, pause, prioritize files (partially implemented with pause) */}
      {/* <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
        (Conceptual: Drag to reorder, more batch actions)
      </p> */}
    </div>
  );
};

export default ConversionQueue;
