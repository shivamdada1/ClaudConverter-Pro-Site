
import React, { useState } from 'react';
import { ConversionJob, HistoryItem, FormatOption } from '../../types';
import { useFileConversion } from '../../hooks/useFileConversion';
import Button from '../ui/Button';
import ProgressBar from '../ui/ProgressBar';
import FileIcon from '../ui/FileIcon';
import { X, Play, Pause, Download, Link as LinkIcon, Settings2, Trash2, RotateCcw, CheckCircle, AlertCircle } from 'lucide-react';

interface ConversionItemProps {
  item: ConversionJob | HistoryItem;
  isHistoryItem?: boolean;
}

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

const ConversionItem: React.FC<ConversionItemProps> = ({ item, isHistoryItem = false }) => {
  const { 
    removeFile, 
    updateFileTargetFormat, 
    startConversion, 
    pauseConversion,
    formatOptions 
  } = useFileConversion();
  
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectedFormat, setSelectedFormat] = useState((item as ConversionJob).targetFormat || '');

  const job = item as ConversionJob; // Type assertion for queue items
  const history = item as HistoryItem; // Type assertion for history items

  const handleFormatChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newFormat = e.target.value;
    setSelectedFormat(newFormat);
    if (!isHistoryItem) {
      updateFileTargetFormat(job.id, newFormat);
    }
  };

  const handleShare = () => {
    if(item.shareLink) {
        navigator.clipboard.writeText(item.shareLink);
        alert(`Link copied to clipboard: ${item.shareLink} (Password protection & expiry are conceptual)`);
    }
  };
  
  const handleDownload = () => {
    alert(`Simulating download of ${item.name}... (URL: ${item.downloadUrl})`);
  };

  const handleRetry = () => {
    if (!isHistoryItem && job.status === 'error') {
        updateFileTargetFormat(job.id, job.targetFormat); // Resets status to pending
        startConversion(job.id);
    }
  };


  return (
    <div className="bg-light-surface dark:bg-dark-surface p-4 rounded-lg shadow-md mb-3 animate-slideInUp flex flex-col sm:flex-row sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
      <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-gray-100 dark:bg-gray-700 rounded-md">
        {item.previewUrl && item.type.startsWith('image/') ? (
          <img src={item.previewUrl} alt={item.name} className="w-full h-full object-cover rounded-md" />
        ) : (
          <FileIcon mimeType={item.type} className="w-7 h-7 text-gray-500 dark:text-gray-400" />
        )}
      </div>

      <div className="flex-grow min-w-0">
        <p className="text-sm font-medium text-light-text-primary dark:text-dark-text-primary truncate" title={item.name}>
          {item.name}
        </p>
        <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary">
          {formatFileSize(item.size)}
          {isHistoryItem && history.convertedSize ? ` → ${formatFileSize(history.convertedSize)}` : ''}
          {!isHistoryItem && job.status === 'processing' && job.estimatedTime ? ` - Est: ${Math.ceil(job.estimatedTime / 60)} min` : ''}
        </p>
        {!isHistoryItem && (job.status === 'uploading' || job.status === 'processing' || job.status === 'paused') && (
          <ProgressBar progress={job.progress} size="sm" className="mt-1" showPercentage />
        )}
        {job.status === 'error' && !isHistoryItem && (
            <p className="text-xs text-red-500 dark:text-red-400 mt-1 flex items-center">
                <AlertCircle size={14} className="mr-1"/> {job.errorMessage || 'Conversion failed'}
            </p>
        )}
         {job.status === 'completed' && !isHistoryItem && (
            <p className="text-xs text-green-500 dark:text-green-400 mt-1 flex items-center">
                <CheckCircle size={14} className="mr-1"/> Ready for download
            </p>
        )}
      </div>

      {!isHistoryItem && (
        <div className="flex items-center space-x-2 flex-shrink-0">
          <select
            value={selectedFormat}
            onChange={handleFormatChange}
            disabled={job.status === 'uploading' || job.status === 'processing'}
            className="block w-full sm:w-32 text-sm rounded-md border-gray-300 dark:border-gray-600 shadow-sm focus:border-electric-blue focus:ring-electric-blue bg-white dark:bg-dark-bg dark:text-dark-text-primary py-1.5 px-2"
          >
            <option value="" disabled>Convert to...</option>
            {formatOptions.map(opt => (
              <option key={opt.value} value={opt.value}>{opt.label}</option>
            ))}
          </select>
          {/* Button for advanced settings - conceptual */}
          {/* <Button variant="ghost" size="sm" onClick={() => setShowAdvanced(!showAdvanced)} title="Advanced Settings">
            <Settings2 size={16} />
          </Button> */}
        </div>
      )}
      
      {isHistoryItem && (
         <div className="flex-shrink-0 text-xs text-light-text-secondary dark:text-dark-text-secondary">
            <p>Converted to: <span className="font-medium text-light-text-primary dark:text-dark-text-primary">{history.targetFormat.toUpperCase()}</span></p>
            <p>{new Date(history.conversionDate).toLocaleString()}</p>
        </div>
      )}


      <div className="flex items-center space-x-1.5 flex-shrink-0">
        {isHistoryItem ? (
          <>
            <Button variant="primary" size="sm" onClick={handleDownload} leftIcon={<Download size={16}/>}>Download</Button>
            {history.shareLink && <Button variant="outline" size="sm" onClick={handleShare} leftIcon={<LinkIcon size={16} />} title="Copy Share Link" />}
            <Button variant="ghost" size="sm" onClick={() => removeFile(item.id)} title="Delete from history">
              <Trash2 size={16} className="text-red-500" />
            </Button>
          </>
        ) : (
          <>
            {job.status === 'pending' && selectedFormat && (
              <Button variant="primary" size="sm" onClick={() => startConversion(job.id)} leftIcon={<Play size={16}/>}>Start</Button>
            )}
            {(job.status === 'uploading' || job.status === 'processing') && (
              <Button variant="secondary" size="sm" onClick={() => pauseConversion(job.id)} leftIcon={<Pause size={16}/>}>Pause</Button>
            )}
            {job.status === 'paused' && selectedFormat && (
                <Button variant="primary" size="sm" onClick={() => startConversion(job.id)} leftIcon={<Play size={16}/>}>Resume</Button>
            )}
            {job.status === 'error' && selectedFormat && (
                <Button variant="outline" size="sm" onClick={handleRetry} leftIcon={<RotateCcw size={16}/>}>Retry</Button>
            )}
             {job.status === 'completed' && ( // This state might be brief as it moves to history, but good to have
                <Button variant="primary" size="sm" onClick={handleDownload} leftIcon={<Download size={16}/>}>Download</Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => removeFile(job.id)} title="Remove from queue">
              <X size={18} />
            </Button>
          </>
        )}
      </div>
      {/* Conceptual Advanced Settings Panel */}
      {/* {showAdvanced && !isHistoryItem && (
        <div className="w-full sm:col-span-full p-3 mt-2 bg-gray-50 dark:bg-gray-800 rounded-md border border-gray-200 dark:border-gray-700">
            <p className="text-sm font-medium">Advanced Settings (Conceptual)</p>
            <p className="text-xs text-gray-500 dark:text-gray-400">E.g., Video Bitrate, Image DPI...</p>
        </div>
      )} */}
    </div>
  );
};

export default ConversionItem;
