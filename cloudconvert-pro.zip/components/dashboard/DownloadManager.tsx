
import React from 'react';
import { useFileConversion } from '../../hooks/useFileConversion';
import ConversionItem from './ConversionItem';
import Button from '../ui/Button';
import { DownloadCloud, Archive, Trash2, History } from 'lucide-react';

const DownloadManager: React.FC = () => {
  const { conversionHistory, clearHistory } = useFileConversion();

  const handleDownloadAllZip = () => {
    // Simulate ZIP bundling and download
    if (conversionHistory.length > 0) {
      alert(`Simulating download of all ${conversionHistory.length} files as a ZIP archive...`);
    } else {
      alert("No files to download.");
    }
  };
  
  if (conversionHistory.length === 0) {
    return (
      <div className="my-8 text-center text-light-text-secondary dark:text-dark-text-secondary animate-fadeIn">
        <History size={48} className="mx-auto mb-4 opacity-50" />
        <p className="text-lg">No conversion history yet.</p>
        <p>Completed conversions will appear here.</p>
      </div>
    );
  }

  return (
    <div className="mt-8 animate-fadeIn">
      <div className="flex flex-col sm:flex-row justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-light-text-primary dark:text-dark-text-primary mb-2 sm:mb-0">
          Conversion History & Downloads ({conversionHistory.length})
        </h3>
        <div className="flex space-x-2">
           <Button 
            variant="primary" 
            onClick={handleDownloadAllZip} 
            disabled={conversionHistory.length === 0}
            leftIcon={<Archive size={18}/>}
          >
            Download All as ZIP
          </Button>
          <Button 
            variant="danger" 
            onClick={clearHistory} 
            disabled={conversionHistory.length === 0}
            leftIcon={<Trash2 size={18}/>}
          >
            Clear History
          </Button>
        </div>
      </div>
      
      <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary mb-3">
        Files are conceptually auto-deleted after 24 hours (adjustable in settings - demo only).
      </p>

      {/* Conceptual: Search and filter */}
      {/* <div className="mb-4">
        <input type="search" placeholder="Search history (e.g., by name, type)..." className="w-full p-2 rounded-md border dark:bg-dark-bg dark:border-dark-border"/>
      </div> */}

      <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-2 custom-scrollbar">
        {conversionHistory.map((item) => (
          <ConversionItem key={item.id} item={item} isHistoryItem />
        ))}
      </div>
    </div>
  );
};

export default DownloadManager;
