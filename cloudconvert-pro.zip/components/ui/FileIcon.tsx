
import React from 'react';
import { FileText, Image, Video, Volume2, Archive, File as FileGeneric } from 'lucide-react'; // Using lucide-react for icons

interface FileIconProps {
  mimeType: string;
  className?: string;
}

const FileIcon: React.FC<FileIconProps> = ({ mimeType, className = "w-6 h-6" }) => {
  if (mimeType.startsWith('image/')) {
    return <Image className={className} />;
  }
  if (mimeType.startsWith('video/')) {
    return <Video className={className} />;
  }
  if (mimeType.startsWith('audio/')) {
    return <Volume2 className={className} />;
  }
  if (mimeType.startsWith('application/pdf')) {
    return <FileText className={className} />;
  }
  if (mimeType.includes('word') || mimeType.includes('document')) {
     return <FileText className={className} />;
  }
  if (mimeType.includes('zip') || mimeType.includes('archive') || mimeType.includes('tar')) {
    return <Archive className={className} />;
  }
  return <FileGeneric className={className} />;
};

export default FileIcon;
