
import React from 'react';

interface ProgressBarProps {
  progress: number; // 0-100
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showPercentage?: boolean;
}

const ProgressBar: React.FC<ProgressBarProps> = ({
  progress,
  size = 'md',
  className = '',
  showPercentage = false,
}) => {
  const heightClasses = {
    sm: 'h-1',
    md: 'h-2',
    lg: 'h-3',
  };

  const normalizedProgress = Math.max(0, Math.min(100, progress));

  return (
    <div className={`w-full bg-gray-200 dark:bg-gray-700 rounded-full ${heightClasses[size]} ${className} overflow-hidden relative`}>
      <div
        className="bg-electric-blue h-full rounded-full transition-all duration-300 ease-out"
        style={{ width: `${normalizedProgress}%` }}
      ></div>
      {showPercentage && (
         <span className={`absolute inset-0 flex items-center justify-center text-xs font-medium ${normalizedProgress > 50 ? 'text-white' : 'text-light-text-primary dark:text-dark-text-primary'}`}>
            {Math.round(normalizedProgress)}%
        </span>
      )}
    </div>
  );
};

export default ProgressBar;
