
import React from 'react';
import { PRIMARY_COLOR, GRADIENT_TEAL_START, GRADIENT_TEAL_END } from '../../constants';

interface LogoProps {
  className?: string;
  isCompact?: boolean;
}

const Logo: React.FC<LogoProps> = ({ className = 'h-10', isCompact = false }) => {
  return (
    <svg 
      viewBox={isCompact ? "0 0 100 50" : "0 0 350 50"} 
      className={`${className} font-sans`} 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <linearGradient id="proGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" style={{ stopColor: GRADIENT_TEAL_START, stopOpacity: 1 }} />
          <stop offset="100%" style={{ stopColor: GRADIENT_TEAL_END, stopOpacity: 1 }} />
        </linearGradient>
      </defs>
      
      {isCompact ? (
        <>
          <text x="0" y="40" fontSize="40" fontWeight="600" fill="currentColor" className="text-light-text-primary dark:text-dark-text-primary">
            CC
          </text>
          <text x="50" y="40" fontSize="40" fontWeight="600" fill="url(#proGradient)">
            Pro
          </text>
        </>
      ) : (
        <>
          <text x="0" y="40" fontSize="40" fontWeight="600" fill="currentColor" className="text-light-text-primary dark:text-dark-text-primary">
            CloudConvert
          </text>
          {/* Arrow Icon ↗↘ (simplified) */}
          <g transform="translate(235, 15) scale(0.7)">
            <path d="M2 12L12 2M12 2H6M12 2V8" stroke={PRIMARY_COLOR} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M22 2L12 12M12 12H18M12 12V6" stroke={PRIMARY_COLOR} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
          </g>
          <text x="265" y="40" fontSize="40" fontWeight="600" fill="url(#proGradient)">
            Pro
          </text>
        </>
      )}
    </svg>
  );
};

export default Logo;
