
import React from 'react';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  srLabel?: string; // Screen reader label
  IconOn?: React.ReactNode;
  IconOff?: React.ReactNode;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ checked, onChange, srLabel = "Toggle", IconOn, IconOff }) => {
  return (
    <button
      type="button"
      className={`${
        checked ? 'bg-electric-blue' : 'bg-gray-300 dark:bg-gray-600'
      } relative inline-flex items-center h-6 rounded-full w-11 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-offset-2 focus-visible:ring-electric-blue dark:focus-visible:ring-offset-dark-bg`}
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
    >
      <span className="sr-only">{srLabel}</span>
      <span
        className={`${
          checked ? 'translate-x-6' : 'translate-x-1'
        } inline-block w-4 h-4 transform bg-white rounded-full transition-transform flex items-center justify-center`}
      >
        {checked && IconOn && <div className="w-3 h-3 text-electric-blue">{IconOn}</div>}
        {!checked && IconOff && <div className="w-3 h-3 text-gray-500">{IconOff}</div>}
      </span>
    </button>
  );
};

export default ToggleSwitch;
