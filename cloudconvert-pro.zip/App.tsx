
import React from 'react';
import { ThemeProvider } from './hooks/useTheme';
import { FileConversionProvider } from './hooks/useFileConversion';
import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import DashboardPage from './components/dashboard/DashboardPage';

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <FileConversionProvider>
        <div className="flex flex-col min-h-screen bg-light-bg dark:bg-dark-bg text-light-text-primary dark:text-dark-text-primary transition-colors duration-300">
          <Header />
          <main className="flex-grow">
            <DashboardPage />
          </main>
          <Footer />
        </div>
      </FileConversionProvider>
    </ThemeProvider>
  );
};

export default App;
