
import { FormatOption, AiSuggestion } from './types';

export const APP_NAME = "CloudConvert Pro";
export const COMPACT_APP_NAME = "CCP";

export const PRIMARY_COLOR = "#2D7FF9"; // Electric Blue
export const GRADIENT_TEAL_START = "#00C6FB";
export const GRADIENT_TEAL_END = "#005BEA";

export const COMMON_FORMATS: FormatOption[] = [
  // Documents
  { value: 'pdf', label: 'PDF', category: 'document' },
  { value: 'docx', label: 'DOCX (Word)', category: 'document' },
  { value: 'txt', label: 'TXT', category: 'document' },
  { value: 'html', label: 'HTML', category: 'document' },
  // Images
  { value: 'jpg', label: 'JPG', category: 'image' },
  { value: 'png', label: 'PNG', category: 'image' },
  { value: 'webp', label: 'WEBP', category: 'image' },
  { value: 'gif', label: 'GIF', category: 'image' },
  { value: 'svg', label: 'SVG', category: 'image' },
  // Video
  { value: 'mp4', label: 'MP4', category: 'video' },
  { value: 'mov', label: 'MOV', category: 'video' },
  { value: 'avi', label: 'AVI', category: 'video' },
  // Audio
  { value: 'mp3', label: 'MP3', category: 'audio' },
  { value: 'wav', label: 'WAV', category: 'audio' },
  // Archive
  { value: 'zip', label: 'ZIP', category: 'archive' },
  { value: 'tar.gz', label: 'TAR.GZ', category: 'archive' },
];

export const AI_SUGGESTIONS: AiSuggestion[] = [
  { id: '1', inputFormat: 'pdf', recommendedFormat: 'docx', reason: 'Best for editing text and layout.' },
  { id: '2', inputFormat: 'png', recommendedFormat: 'jpg', reason: 'Smaller file size for web sharing.' },
  { id: '3', inputFormat: 'jpg', recommendedFormat: 'webp', reason: 'Modern format with better compression and quality.' },
  { id: '4', inputFormat: 'mov', recommendedFormat: 'mp4', reason: 'Widely compatible for video playback.' },
  { id: '5', inputFormat: 'any', recommendedFormat: 'zip', reason: 'Bundle multiple files for easy download.' },
];

export const MAX_FILE_SIZE_MB = 100; // Example limit
export const MAX_CONCURRENT_UPLOADS = 3;
export const MAX_CONCURRENT_CONVERSIONS = 2;

export const MOCK_CONVERSION_DURATION_MS_PER_MB = 500; // 0.5 seconds per MB for simulation
export const MOCK_UPLOAD_DURATION_MS_PER_MB = 200; // 0.2 seconds per MB for simulation
