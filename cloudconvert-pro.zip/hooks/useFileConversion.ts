
import React, { useState, useCallback, useEffect, ReactNode, createContext, useContext } from 'react';
import { FileObject, ConversionJob, HistoryItem, FormatOption, AiSuggestion } from '../types';
import { COMMON_FORMATS, AI_SUGGESTIONS, MOCK_CONVERSION_DURATION_MS_PER_MB, MOCK_UPLOAD_DURATION_MS_PER_MB } from '../constants';

interface FileConversionContextType {
  filesToConvert: ConversionJob[];
  conversionHistory: HistoryItem[];
  addFiles: (newFiles: File[]) => void;
  removeFile: (fileId: string) => void;
  updateFileTargetFormat: (fileId: string, targetFormat: string) => void;
  startConversion: (fileId: string) => void;
  startAllConversions: () => void;
  pauseConversion: (fileId: string) => void;
  clearQueue: () => void;
  clearHistory: () => void;
  getAiSuggestions: (inputFileType: string) => AiSuggestion[];
  formatOptions: FormatOption[];
  isProcessing: boolean;
  overallProgress: number;
}

const FileConversionContext = createContext<FileConversionContextType | undefined>(undefined);

export const FileConversionProvider: React.FC<{children: ReactNode}> = ({ children }) => {
  const [filesToConvert, setFilesToConvert] = useState<ConversionJob[]>([]);
  const [conversionHistory, setConversionHistory] = useState<HistoryItem[]>([]);
  const [isProcessing, setIsProcessing] = useState(false); // Tracks if any conversion is active

  const addFiles = useCallback((newFiles: File[]) => {
    const newJobs: ConversionJob[] = newFiles.map((file) => {
      const fileId = `${file.name}-${file.size}-${Date.now()}`;
      let previewUrl: string | undefined;
      if (file.type.startsWith('image/')) {
          previewUrl = URL.createObjectURL(file);
      }
      return {
        id: fileId,
        file,
        name: file.name,
        size: file.size,
        type: file.type,
        status: 'pending',
        progress: 0,
        targetFormat: '', // User will set this
        previewUrl,
      };
    });
    setFilesToConvert((prev) => [...prev, ...newJobs]);
  }, []);

  const removeFile = useCallback((fileId: string) => {
    const fileToRemove = filesToConvert.find(f => f.id === fileId); // Find before filtering
    if (fileToRemove?.previewUrl) {
        URL.revokeObjectURL(fileToRemove.previewUrl);
    }
    // Also clear interval if active for this file before removing
    if (fileToRemove?._intervalId) {
        clearInterval(fileToRemove._intervalId);
    }
    setFilesToConvert((prev) => prev.filter((f) => f.id !== fileId));
  }, [filesToConvert]); // filesToConvert dependency is important here

  const updateFileTargetFormat = useCallback((fileId: string, targetFormat: string) => {
    setFilesToConvert((prev) =>
      prev.map((f) => (f.id === fileId ? { ...f, targetFormat, status: 'pending', progress: 0, errorMessage: undefined } : f))
    );
  }, []);

  const simulateProcessing = useCallback((fileJob: ConversionJob, processType: 'uploading' | 'processing') => {
    const durationPerMb = processType === 'uploading' ? MOCK_UPLOAD_DURATION_MS_PER_MB : MOCK_CONVERSION_DURATION_MS_PER_MB;
    const totalDuration = Math.max(500, (fileJob.size / (1024 * 1024)) * durationPerMb); // Min 0.5s
    let currentProgress = 0;
    
    const intervalId = window.setInterval(() => {
      currentProgress += 10; // Simulate progress in 10% chunks
      
      // Find the latest state of the fileJob in case it was paused/resumed or changed
      const currentFileState = filesToConvert.find(f => f.id === fileJob.id);
      if (!currentFileState || currentFileState.status === 'paused') { // If file removed or paused, stop processing
          clearInterval(intervalId);
          return;
      }

      if (currentProgress <= 100) {
        setFilesToConvert((prev) =>
          prev.map((f) =>
            f.id === fileJob.id ? { ...f, progress: currentProgress, status: processType } : f
          )
        );
      } else {
        clearInterval(intervalId);
        if (processType === 'uploading') {
             const updatedJobForChaining = filesToConvert.find(f => f.id === fileJob.id); // Get latest state
             if(updatedJobForChaining && updatedJobForChaining.targetFormat) { // Check if still exists
                setFilesToConvert(prev => prev.map(f => f.id === fileJob.id ? {...f, status: 'processing', progress: 0} : f));
                simulateProcessing({...updatedJobForChaining, status: 'processing', progress: 0 }, 'processing');
             } else if (updatedJobForChaining) { // Still exists but no target format (edge case)
                setFilesToConvert(prev => prev.map(f => f.id === fileJob.id ? {...f, status: 'pending', progress: 100} : f));
             }
        } else { // Processing completed
          const completedFile: HistoryItem = {
            ...fileJob, // Use the initial fileJob passed, not the potentially modified currentFileState from outer scope
            status: 'completed',
            progress: 100,
            downloadUrl: `simulated_download_path_for_${fileJob.name.split('.')[0]}.${fileJob.targetFormat}`,
            shareLink: `https://cloudconvert.pro/share/${fileJob.id}`,
            convertedSize: fileJob.size * (Math.random() * 0.5 + 0.5),
            conversionDate: new Date(),
            _intervalId: undefined, // Clear intervalId from the completed item
          };
          setFilesToConvert((prev) => prev.filter((f) => f.id !== fileJob.id));
          setConversionHistory((prev) => [completedFile, ...prev.slice(0, 19)]);
        }
      }
    }, totalDuration / 10);

     setFilesToConvert((prev) =>
      prev.map((f) =>
        f.id === fileJob.id ? { ...f, _intervalId: intervalId, status: processType, progress: 0 } : f
      )
    );
  }, [filesToConvert]); // filesToConvert is a key dependency


  const startConversion = useCallback((fileId: string) => {
    const fileToConvert = filesToConvert.find((f) => f.id === fileId);
    if (fileToConvert && fileToConvert.targetFormat && (fileToConvert.status === 'pending' || fileToConvert.status === 'paused')) {
      setIsProcessing(true);
      // Clear any previous error message
      setFilesToConvert(prev => prev.map(f => f.id === fileId ? {...f, errorMessage: undefined } : f));
      simulateProcessing(fileToConvert, 'uploading');
    } else if (fileToConvert && !fileToConvert.targetFormat) {
        setFilesToConvert(prev => prev.map(f => f.id === fileId ? {...f, status: 'error', errorMessage: 'Target format not selected.'} : f));
    }
  }, [filesToConvert, simulateProcessing]);

  const startAllConversions = useCallback(() => {
    let anyConversionStarted = false;
    filesToConvert.forEach(file => {
        if (file.targetFormat && (file.status === 'pending' || file.status === 'paused')) {
            startConversion(file.id);
            anyConversionStarted = true;
        } else if (!file.targetFormat && file.status !== 'error') { // Only set error if not already an error
             setFilesToConvert(prev => prev.map(f => f.id === file.id ? {...f, status: 'error', errorMessage: 'Target format not selected.'} : f));
        }
    });
    if (anyConversionStarted) setIsProcessing(true);
  }, [filesToConvert, startConversion]);
  
  const pauseConversion = useCallback((fileId: string) => {
    setFilesToConvert((prev) =>
      prev.map((f) => {
        if (f.id === fileId && (f.status === 'uploading' || f.status === 'processing')) {
          if (f._intervalId) clearInterval(f._intervalId);
          return { ...f, status: 'paused', _intervalId: undefined };
        }
        return f;
      })
    );
  }, []);

  const clearQueue = useCallback(() => {
    filesToConvert.forEach(f => {
        if (f.previewUrl) URL.revokeObjectURL(f.previewUrl);
        if (f._intervalId) clearInterval(f._intervalId);
    });
    setFilesToConvert([]);
  }, [filesToConvert]);

  const clearHistory = useCallback(() => {
    conversionHistory.forEach(f => {
        if (f.previewUrl) URL.revokeObjectURL(f.previewUrl); // History items might have preview if they were images
    });
    setConversionHistory([]);
  }, [conversionHistory]);

  const getAiSuggestions = useCallback((inputFileType: string): AiSuggestion[] => {
    const generalSuggestions = AI_SUGGESTIONS.filter(s => s.inputFormat === 'any');
    if (!inputFileType) return generalSuggestions;
    
    const simpleInputType = inputFileType.split('/')[1]?.toLowerCase() || inputFileType.toLowerCase();
    const specificSuggestions = AI_SUGGESTIONS.filter(s => {
        return s.inputFormat.toLowerCase() === simpleInputType;
    });
    return [...specificSuggestions, ...generalSuggestions];
  }, []);

  useEffect(() => {
    const currentlyProcessing = filesToConvert.some(f => f.status === 'uploading' || f.status === 'processing');
    setIsProcessing(currentlyProcessing);
  }, [filesToConvert]);

  const calculateOverallProgress = (): number => {
    const activeFiles = filesToConvert.filter(f => f.status === 'uploading' || f.status === 'processing' || f.status === 'paused');
    if (activeFiles.length === 0) return 0;
    
    const totalSizeOfActive = activeFiles.reduce((acc, f) => acc + f.size, 0);
    if (totalSizeOfActive === 0) return 0;
    
    const completedSizeOfActive = activeFiles.reduce((acc, f) => {
        return acc + (f.size * (f.progress / 100));
    }, 0);
    
    return Math.round((completedSizeOfActive / totalSizeOfActive) * 100);
  };
  const overallProgressValue = calculateOverallProgress();


  return React.createElement(
    FileConversionContext.Provider,
    {
      value: {
        filesToConvert,
        conversionHistory,
        addFiles,
        removeFile,
        updateFileTargetFormat,
        startConversion,
        startAllConversions,
        pauseConversion,
        clearQueue,
        clearHistory,
        getAiSuggestions,
        formatOptions: COMMON_FORMATS,
        isProcessing,
        overallProgress: overallProgressValue
      }
    },
    children
  );
};

export const useFileConversion = (): FileConversionContextType => {
  const context = useContext(FileConversionContext);
  if(!context) {
    throw new Error('useFileConversion must be used within a FileConversionProvider');
  }
  return context;
}
